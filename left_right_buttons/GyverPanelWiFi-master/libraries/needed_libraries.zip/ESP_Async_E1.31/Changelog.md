
# Changelog

### 1.0.2

- Added callback support

### 1.0.1

- Added ESP32 support.

### 1.0.0

- Initial release.
